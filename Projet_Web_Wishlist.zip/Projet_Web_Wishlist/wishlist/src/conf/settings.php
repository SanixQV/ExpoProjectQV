<?php

return [
    'settings' => [
        'displayErrorDetails' => true,
        'dbfile' => __DIR__ . '/dbconfig.ini'
    ]
];