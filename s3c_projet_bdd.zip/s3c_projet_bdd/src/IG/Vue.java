package IG;

import javax.swing.JTextArea;
/**
 * 
 * @author NICOL, VRIGNON
 *
 */
public class Vue extends JTextArea implements Observateur {
	
	/**
	 * Constructeur de vue
	 */
	public Vue() {
		super(5,5);
		this.setFocusable(false);
	}
	
		/**
		 * actualise l'affichage
		 */
		@Override
		public void actualiser(Sujet s) {
			Modele m = (Modele)s;
			this.setText(m.getResultat());
	}
}
