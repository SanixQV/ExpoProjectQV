package IG;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JComboBox;
/**
 * 
 * @author NICOL, VRIGNON
 *
 */
public class ControleurModifications implements ActionListener{

	private Modele m;
	private List<String> fonctionnalites;
	
	
	/**
	 * Constructeur ControleurFonctionnalites
	 * @param m Modele
	 * @param conn Connection
	 */
	public ControleurModifications(Modele m){
		this.m = m;
		//instanciation de la liste des fonctionnalit�s
		this.fonctionnalites = new ArrayList<String>();
		this.fonctionnalites.add("Veuillez rentrer une question");
		this.fonctionnalites.add("Liste des articles �crits par un chercheur");
		this.fonctionnalites.add("Liste des co-auteurs pour un chercheur donn�");
		this.fonctionnalites.add("Liste des laboratoires pour un chercheur donn�");
		this.fonctionnalites.add("Liste auteurs ayant annot� un certain nombre d'articles");
		this.fonctionnalites.add("Moyenne des notes donn�es pour un chercheur");
		this.fonctionnalites.add("Nombre d'articles, de notes et moyenne obtenues pour chaque chercheur d'un laboratoire");
		this.fonctionnalites.add("V�rifier si la note maximale d'un article n'a pas �t� donn�e par un chercheur du m�me labo que l'auteur");
	}
	
	/**
	 * methode actionPerformed qui lance une question en fonction de celle que l'on choisit dans le JCombox
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		//on r�cupere le JComboBox
		JComboBox<String> jc = (JComboBox<String>)e.getSource();
		//On r�cup�re la valeur de l'item s�lectionn�
		String tmp = (String) jc.getSelectedItem();
		//on instancie le resultat par la valeur la plus redondante
		String res = "Veuillez donner une adresse mail";
		//On r�cup�re l'indice de la fonctionnalit� correspondant � l'item s�lectionn� pour l'utiliser dans le switch
		int i = this.fonctionnalites.indexOf(tmp);
		switch(i){
			case 1 : 
				m.ajouterResultat(res);
				break;
			case 2 : 
				m.ajouterResultat(res);
				break;
			case 3 : 
				res = "";
				m.ajouterResultat(res);
				break;
			case 4 : 
				res = "Veuillez rentrer un nombre minimum d'articles";
				m.ajouterResultat(res);
				break;
			case 5 :
				m.ajouterResultat(res);
				break;
			case 6 :
				res = "Veuillez donner un nom de laboratoire";
				m.ajouterResultat(res);
				break;
			case 7 : 
				res = "Veuillez donner le titre d'un article pour la v�rification"; 
				m.ajouterResultat(res);
				break;
		}
	}

}
