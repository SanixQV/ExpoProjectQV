package IG;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
/**
 * 
 * @author NICOL, BENOIT
 *
 */

public class Principale {
	public static void main(String[] args) throws SQLException {
		//scanner qui permet de r�cup�rer l'url, et les logs
		Scanner sc = new Scanner(System.in);
		System.out.println("Veuillez rentrer l'URL d'acc�s � votre base de donn�es");
		String url = sc.next();
		System.out.println("Veuillez rentrer votre identifiant");
		String id = sc.next();
		System.out.println("Veuillez rentrer votre mot de passe");
		String mdp = sc.next();
		// cr�ation de la connexion � la base
		Connection conn = DriverManager.getConnection(url, id, mdp);
		Modele modele = new Modele();
		//ajout des controleurs au modele
		ControleurFonctionnalites cf = new ControleurFonctionnalites(modele, conn);
		ControleurModifications cm = new ControleurModifications(modele);
		Vue v = new Vue();
		JTextField saisie = new JTextField(10);
		JButton valider = new JButton ("Valider");
		//on enregistre la vue dans la liste des observateurs
		modele.enregistrerObservateur(v);
		//on cr�� les diff�rents items du JComboBox
		String[] tab = {"Veuillez rentrer une question", "Liste des articles �crits par un chercheur", "Liste des co-auteurs pour un chercheur donn�", "Liste des laboratoires pour un chercheur donn�", "Liste auteurs ayant annot� un certain nombre d'articles", "Moyenne des notes donn�es pour un chercheur", "Nombre d'articles, de notes et moyenne obtenues pour chaque chercheur d'un laboratoire", "V�rifier si la note maximale d'un article n'a pas �t� donn�e par un chercheur du m�me labo que l'auteur"};
		JComboBox<String> jcb = new JComboBox<String>(tab);
		//on ajoute l'actionListener au JComboBox
		jcb.addActionListener(cm);
		JPanel nord = new JPanel(new GridLayout(1, 3));
		//on ajoute l'actionListener au JButton
		valider.addActionListener(cf);
		//on ajoute dans le Jpanel nord le Jbutton, le JComboBox et le JTextField
		nord.add(jcb);
		nord.add(saisie);
		nord.add(valider);
		
		JPanel centre = new JPanel();
		//on ajoute la vue au JPanel centre
		centre.add(v);
		JFrame frame = new JFrame();
		//On place les 2 jpanel dans le JFrame
		frame.getContentPane().add(nord, BorderLayout.NORTH);
		frame.getContentPane().add(centre, BorderLayout.CENTER);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
		sc.close();
	}
}
