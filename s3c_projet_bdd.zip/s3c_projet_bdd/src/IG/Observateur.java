package IG;
/**
 * 
 * @author NICOL, VRIGNON
 *
 */
public interface Observateur {
	
	
	/**
	 * methode qui permet d'actualiser l'affichage
	 * @param s Sujet
	 */
	public void actualiser(Sujet s);
}
