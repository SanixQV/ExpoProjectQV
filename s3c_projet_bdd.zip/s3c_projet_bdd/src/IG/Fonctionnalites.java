package IG;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * class Fonctionnalites
 * 
 * @author Travail
 *
 */
public class Fonctionnalites {

	/**
	 * Methode determinant la liste des articles ecrits par un auteur donne
	 * 
	 * @param conn  Connection
	 * @param param parametre de la requete
	 * @return String : le resultat de la requete
	 * @throws SQLException
	 */
	public String question1(Connection conn, String param) {
		String affichage = "";
		try {
			PreparedStatement pstmt;
			PreparedStatement pstmt2;
			ResultSet res;
			ResultSet res2;

			// On recup�re le nom et le pr�nom de l'auteur � partir de son email
			String querySelection = "Select NOMCHERCHEUR, PRENOMCHERCHEUR from CHERCHEUR where EMAIL = ?";

			// On r�cup�re les titres des articles �crits par cet auteur
			String querySelection2 = "Select TITRE from ECRIRE where EMAIL = ? order by TITRE";
			pstmt = conn.prepareStatement(querySelection);
			pstmt2 = conn.prepareStatement(querySelection2);

			// On met le m�me param�tre car c'est le m�me email
			pstmt.setString(1, param);
			pstmt2.setString(1, param);

			res = pstmt.executeQuery();
			res.next();

			// On sait que l'on a qu'une seule ligne, on l'ajoute � l'affichage
			affichage += "L'auteur " + res.getString(1) + " " + res.getString(2)
					+ " a �crit le(s) article(s) suivant(s) :\n";

			res2 = pstmt2.executeQuery();
			while (res2.next()) {
				affichage += "   - " + res2.getString(1) + "\n";
			}

			pstmt.close();
			pstmt2.close();

			res.close();
			res2.close();
		}
		catch (SQLException e) {
			affichage += "ERREUR : Veuillez rentrer un email valide";
		}
		
		return affichage;
	}

	/**
	 * Methode qui affiche la liste des co-auteurs d un auteur donne
	 * 
	 * @param conn  Connection
	 * @param param parametre de la requete
	 * @return String : le resultat de la requete
	 * @throws SQLException
	 */
	public String question2(Connection conn, String param) {
		String affichage = "";
		try {
			PreparedStatement pstmt;
			PreparedStatement pstmt2;
			ResultSet res;
			ResultSet res2;

			// On recup�re le nom et le pr�nom de l'auteur � partir de son email
			String querySelection = "Select NOMCHERCHEUR, PRENOMCHERCHEUR from CHERCHEUR where EMAIL = ?";

			// On r�cup�re les co-auteurs de l'auteur
			String querySelection2 = "Select DISTINCT ECRIRE.EMAIL, NOMCHERCHEUR, PRENOMCHERCHEUR from ECRIRE inner join CHERCHEUR on ECRIRE.EMAIL = CHERCHEUR.EMAIL where TITRE in (select TITRE from ECRIRE where EMAIL = ?)";

			pstmt = conn.prepareStatement(querySelection);
			pstmt2 = conn.prepareStatement(querySelection2);

			pstmt.setString(1, param);

			res = pstmt.executeQuery();
			res.next();

			// On sait que l'on a qu'une seule ligne, on l'ajoute � l'affichage
			affichage += "Le(s) co-auteur(s) de " + res.getString(1) + " " + res.getString(2)
					+ " est/sont le(s) suivant(s) :\n";

			pstmt2.setString(1, param);
			res2 = pstmt2.executeQuery();

			while (res2.next()) {

				// On ajoute tous les co-auteurs sauf lui-m�me
				if (!res2.getString(2).equals(res.getString(1)) && !res2.getString(3).equals(res.getString(2)))
					affichage += "   - " + res2.getString(2) + " " + res2.getString(3) + "\n";
			}

			pstmt.close();
			pstmt2.close();
			res.close();
			res2.close();
		}
		catch (SQLException e) {
			affichage += "ERREUR : Veuillez rentrer un email valide";
		}
		
		return affichage;
	}

	/**
	 * 
	 * @param conn
	 * @return
	 * @throws SQLException
	 */
	public String question3(Connection conn) {
		String affichage = "";
		try {
			PreparedStatement pstmt;
			PreparedStatement pstmt2;
			ResultSet res;
			ResultSet res2;

			// On r�cup�re tous les email, nom et pr�nom des chercheurs travaillant dans un
			// ou plusieurs laboratoires
			String querySelection = "Select DISTINCT TRAVAILLER.EMAIL, NOMCHERCHEUR, PRENOMCHERCHEUR from TRAVAILLER inner join CHERCHEUR on TRAVAILLER.EMAIL = CHERCHEUR.EMAIL";

			// On r�cup�re les laboratoires dans lesquels travaille l'auteur
			String querySelection2 = "Select NOMLABO from TRAVAILLER where EMAIL = ?";

			pstmt = conn.prepareStatement(querySelection);
			res = pstmt.executeQuery();
			while (res.next()) {

				// On r�cup�re l'email, le nom et le pr�nom du chercheur
				String email = res.getString(1);
				String nom = res.getString(2);
				String prenom = res.getString(3);

				pstmt2 = conn.prepareStatement(querySelection2);
				pstmt2.setString(1, email);

				affichage += "Le chercheur " + nom + " " + prenom
						+ " travaille dans le(s) laboratoire(s) suivant(s) :\n";

				res2 = pstmt2.executeQuery();

				while (res2.next()) {
					affichage += "   - " + res2.getString(1) + "\n";
				}
				affichage += "\n";
				pstmt2.close();
				res2.close();
			}

			pstmt.close();
			res.close();
		}
		catch (SQLException e) {
			affichage += e;
		}
		
		return affichage;
	}

	/**
	 * 
	 * @param conn
	 * @param param
	 * @return
	 * @throws SQLException
	 */
	public String question4(Connection conn, int param) {
		String affichage = "";
		try {
			PreparedStatement pstmt;
			ResultSet res;

			// On r�cup�re la liste des chercheurs ayant annot� au moins un nombre param
			// d'articles
			String querySelection = "Select NOMCHERCHEUR, PRENOMCHERCHEUR from ANNOTER inner join CHERCHEUR on ANNOTER.EMAIL = CHERCHEUR.EMAIL group by NOMCHERCHEUR, PRENOMCHERCHEUR having count(TITRE) >= ? order by NOMCHERCHEUR";

			affichage += "Les auteurs ayant annot� plus de " + param + " fois des articles sont les suivants :\n";

			pstmt = conn.prepareStatement(querySelection);
			pstmt.setInt(1, param);
			res = pstmt.executeQuery();

			while (res.next()) {
				affichage += "   - " + res.getString(1) + " " + res.getString(2) + "\n";
			}

			pstmt.close();
			res.close();
		}
		catch (SQLException e) {
			affichage += "ERREUR : Veuillez rentrer un nombre valide";
		}
		
		return affichage;
	}

	/**
	 * 
	 * @param conn
	 * @param param
	 * @return
	 * @throws SQLException
	 */
	public String question5(Connection conn, String param) {
		String affichage = "";
		try {
			PreparedStatement pstmt;
			ResultSet res;

			// On r�cup�re le nom et le pr�nom d'un chercheur donn� et la moyenne des notes
			// qu'il a attribu�es
			String querySelection = "Select NOMCHERCHEUR, PRENOMCHERCHEUR, AVG(NOTE) from CHERCHEUR inner join NOTER on CHERCHEUR.EMAIL = NOTER.EMAIL where NOTER.EMAIL = ? group by(NOMCHERCHEUR, PRENOMCHERCHEUR)";

			pstmt = conn.prepareStatement(querySelection);
			pstmt.setString(1, param);
			res = pstmt.executeQuery();

			while (res.next()) {
				affichage += "Le chercheur " + res.getString(1) + " " + res.getString(2)
						+ " a attribu� une moyenne de notes de " + res.getDouble(3) + "\n";
			}

			pstmt.close();
		}
		catch (SQLException e) {
			affichage += "ERREUR : Veuillez rentrer un email valide";
		}
		
		return affichage;
	}

	/**
	 * 
	 * @param conn
	 * @param param
	 * @return
	 * @throws SQLException
	 */
	public String question6(Connection conn, String param) {
		String affichage = "";
		try {
			PreparedStatement pstmt;
			PreparedStatement pstmt2;
			PreparedStatement pstmt3;
			ResultSet res;
			ResultSet res2;
			ResultSet res3;

			// On r�cup�re les auteurs et le nombre d'articles qu'ils ont not�, class�s par
			// le nombre d'articles not�s
			String querySelection = "Select ECRIRE.EMAIL, COUNT(DISTINCT TITRE), NOMCHERCHEUR, PRENOMCHERCHEUR from ECRIRE inner join TRAVAILLER on ECRIRE.EMAIL = TRAVAILLER.EMAIL inner join CHERCHEUR on TRAVAILLER.EMAIL = CHERCHEUR.EMAIL where NOMLABO = ? group by ECRIRE.EMAIL, NOMCHERCHEUR, PRENOMCHERCHEUR order by COUNT(DISTINCT TITRE) desc";

			// On r�cup�re tous les articles �crits par un chercheur
			String querySelection2 = "Select TITRE from ECRIRE where EMAIL = ?";

			// On r�cup�re le nombre de notes et la moyenne re�ues pour un article donn�
			String querySelection3 = "Select COUNT(NOTE), AVG(NOTE) from NOTER where TITRE = ?";

			String nomLabo = param;

			affichage += "Le laboratoire " + nomLabo + " engage le(s) chercheur(s) suivant(s) :\n";

			pstmt = conn.prepareStatement(querySelection);
			pstmt.setString(1, nomLabo);
			res = pstmt.executeQuery();

			while (res.next()) {

				String nom = res.getString(3);
				String prenom = res.getString(4);
				int nbNotes = 0;
				double moyenne = 0;
				int nbLignes = 0;

				pstmt2 = conn.prepareStatement(querySelection2);
				String email = res.getString(1);
				pstmt2.setString(1, email);
				res2 = pstmt2.executeQuery();
				while (res2.next()) {
					pstmt3 = conn.prepareStatement(querySelection3);
					String titre = res2.getString(1);
					pstmt3.setString(1, titre);
					res3 = pstmt3.executeQuery();
					res3.next();
					nbNotes += res3.getInt(1);
					moyenne += res3.getDouble(2);
					nbLignes++;
				}
				if (nbLignes == 0)
					nbLignes = 1;

				moyenne /= nbLignes;

				affichage += "   - " + nom + " " + prenom + " qui a �crit " + res.getInt(2) + " articles, a re�u "
						+ nbNotes + " notes avec une moyenne de " + moyenne + "\n";
			}
			pstmt.close();
		}
		catch (SQLException e) {
			affichage += "ERREUR : Veuillez rentrer un nom de laboratoire valide";
		}
		
		return affichage;
	}

	public String question7(Connection conn, String param) throws SQLException {
		String affichage = "";
		try {
			boolean trouve = false;
			boolean ici = false;
			PreparedStatement pstmt;
			PreparedStatement pstmt2;
			PreparedStatement pstmt3;
			ResultSet res;
			ResultSet res2;
			ResultSet res3;
			String querySelection = "Select NOTER.EMAIL, MAX(NOTE), NOMLABO from NOTER inner join ECRIRE on NOTER.TITRE = ECRIRE.TITRE inner join Travailler on NOTER.EMAIL = TRAVAILLER.EMAIL where NOTER.TITRE = ? and NOTE >= ALL(SELECT NOTE from NOTER where TITRE =?) group by NOMLABO, NOTER.EMAIL";
			String querySelection2 = "Select Email from Ecrire where TITRE = ? ";
			String querySelection3 = "Select LABORATOIRE.NOMLABO from LABORATOIRE inner join TRAVAILLER on LABORATOIRE.NOMLABO = TRAVAILLER.NOMLABO where EMAIL = ?";

			pstmt = conn.prepareStatement(querySelection);
			pstmt2 = conn.prepareStatement(querySelection2);
			pstmt3 = conn.prepareStatement(querySelection3);
			String s = param;
			pstmt.setString(1, s);
			pstmt.setString(2, s);
			res = pstmt.executeQuery();
			while (res.next()) {
				String nomLaboNote = res.getString(3);
				pstmt2.setString(1, s);
				res2 = pstmt2.executeQuery();
				while (res2.next()) {
					String email = res2.getString(1);
					pstmt3.setString(1, email);
					res3 = pstmt3.executeQuery();
					while (res3.next()) {
						ici = true;
						String NomLabo = res3.getString(1);
						if (NomLabo.equals(nomLaboNote)) {
							trouve = true;
						}

					}
				}
			}
			if (ici) {
				if (trouve)
					affichage += "ATTENTION : la note maximale de cet article a �t� attribu�e par un chercheur appartenant au m�me laboratoire que l'un des auteurs de cet article";
				else
					affichage += "Tout est en ordre.";
			} else
				affichage += "Param�tre incorrect";
			pstmt.close();
		}
		catch (SQLException e) {
			affichage += "ERREUR : Veuillez rentrer un titre valide";
		}
		
		return affichage;
	}
}
