package IG;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;
/**
 * 
 * @author NICOL,BENOIT
 *
 */

public class ControleurFonctionnalites implements ActionListener {
	private Fonctionnalites f;
	private Modele m;
	private Connection conn;
	private List<String> fonctionnalites;
	
	
	/**
	 * Constructeur ControleurFonctionnalites
	 * @param m Modele
	 * @param conn Connection
	 */
	public ControleurFonctionnalites(Modele m, Connection conn){
		this.f = new Fonctionnalites();
		this.m = m;
		this.conn = conn;
		//instanciation de la liste des fonctionnalit�s
		this.fonctionnalites = new ArrayList<String>();
		this.fonctionnalites.add("Veuillez rentrer une question");
		this.fonctionnalites.add("Liste des articles �crits par un chercheur");
		this.fonctionnalites.add("Liste des co-auteurs pour un chercheur donn�");
		this.fonctionnalites.add("Liste des laboratoires pour un chercheur donn�");
		this.fonctionnalites.add("Liste auteurs ayant annot� un certain nombre d'articles");
		this.fonctionnalites.add("Moyenne des notes donn�es pour un chercheur");
		this.fonctionnalites.add("Nombre d'articles, de notes et moyenne obtenues pour chaque chercheur d'un laboratoire");
		this.fonctionnalites.add("V�rifier si la note maximale d'un article n'a pas �t� donn�e par un chercheur du m�me labo que l'auteur");
	}
	
	/**
	 * methode actionPerformed qui lance une question en fonction de celle que l'on choisit dans le JCombox
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		//On recupere le JComboBox
		JComboBox<String> jc = (JComboBox<String>) (((JButton) e.getSource()).getParent().getComponentAt(0,0));
		//On r�cup�re les valeurs tap�s dans le JTextField
		String param = ((JTextField) (((JButton)e.getSource()).getParent().getComponent(1))).getText();
		//On r�cup�re la valeur de l'item s�lectionn�
		String tmp = (String) jc.getSelectedItem();
		String res = "";
		//On r�cup�re l'indice de la fonctionnalit� correspondant � l'item s�lectionn� pour l'utiliser dans le switch
		int i = this.fonctionnalites.indexOf(tmp);
		try {
			switch(i){
				case 1 : 
					res = f.question1(conn, param);
					m.ajouterResultat(res);
					break;
				case 2 : 
					res = f.question2(conn, param);
					m.ajouterResultat(res);
					break;
				case 3 : 
					res = f.question3(conn);
					m.ajouterResultat(res);
					break;
				case 4 : 
					try {
						int p = Integer.parseInt(param);
						res = f.question4(conn, p);
						m.ajouterResultat(res);
					}
					catch(NumberFormatException exp) {
						String s = "";
						s += exp;
						m.ajouterResultat(s);
					}
					
					break;
				case 5 :
					res = f.question5(conn, param);
					m.ajouterResultat(res);
					break;
				case 6 :
					res = f.question6(conn, param);
					m.ajouterResultat(res);
					break;
				case 7 : 
					res = f.question7(conn, param);
					m.ajouterResultat(res);
					break;
			}
		}
		catch(SQLException exp) {
			exp.printStackTrace();
		}
	}
	
}
