package IG;

import java.util.ArrayList;
/**
 * 
 * @author NICOL, VRIGNON
 *
 */

public class Modele implements Sujet {
	private ArrayList<Observateur> observateurs;
	private String resultat;
	
	/**
	 * Constructeur du modele
	 */
	public Modele() {
		this.resultat = "";
		this.observateurs = new ArrayList<Observateur> ();
	}
	
	/**
	 * getter qui retourne l'attribut resultat
	 * @return	resultats
	 */
	public String getResultat() {
		return this.resultat;
	}
	
	
	/**
	 * ajoute un resultat dans l'attribut resultat
	 * @param mot
	 */
	public void ajouterResultat(String resultat) {
		this.resultat = resultat;
		this.notifierObservateurs();
	}
	
	
	/**
	 *m�thode qui notifie observateur
	 */
	public void notifierObservateurs() {
		for (int i = 0; i < this.observateurs.size(); i++) {
			Observateur observer = this.observateurs.get(i);
			observer.actualiser(this);
		}
	}

	/**
	 *methode qui enregistre les observateurs
	 */
	@Override
	public void enregistrerObservateur(Observateur o) {
		this.observateurs.add(o);
		
	}

	/**
	 * methode qui supprime un observateur
	 */
	@Override
	public void supprimerObservateur(Observateur o) {
		int i = this.observateurs.indexOf(o);
		if (i >= 0) {
			this.observateurs.remove(i);
		}

	}
}
