package api;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Question2 {
	public static void main(String[] args) {
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		Connection conn;
		PreparedStatement pstmt;
		ResultSet res;
		Scanner sc = new Scanner(System.in);
		String querySelection = "Select DISTINCT EMAIL from ECRIRE where TITRE in (select TITRE from ECRIRE where EMAIL = ?)";
		try {
			conn = DriverManager.getConnection(url, args[0], args[1]);
			
			pstmt = conn.prepareStatement(querySelection);
			String s = sc.next();
			pstmt.setString(1, s);
			//pstmt.executeUpdate();
			res = pstmt.executeQuery();
			while (res.next()) {
				System.out.println("les co-auteurs de" + s + "sont" + res.getString(1));
			}
			sc.close();
			pstmt.close();
			conn.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
