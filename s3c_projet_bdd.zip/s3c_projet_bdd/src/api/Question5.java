package api;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Question5 {
	public static void main(String[] args) {
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		Connection conn;
		PreparedStatement pstmt;
		ResultSet res;
		Scanner sc = new Scanner(System.in);
		String querySelection = "Select NOMCHERCHEUR, PRENOMCHERCHEUR, AVG(NOTE) from CHERCHEUR inner join NOTER on CHERCHEUR.EMAIL = NOTER.EMAIL where NOTER.EMAIL = ? group by(NOMCHERCHEUR, PRENOMCHERCHEUR)";
		try {
			conn = DriverManager.getConnection(url, args[0], args[1]);
			
			pstmt = conn.prepareStatement(querySelection);
			String s = sc.next();
			pstmt.setString(1, s);
			//pstmt.executeUpdate();
			res = pstmt.executeQuery();
			while (res.next()) {
				System.out.println("NOM : " + res.getString(1) + "\t|\tPRENOM : " + res.getString(2) + "\t|\tNOTE : " + res.getDouble(3));
			}
			sc.close();
			pstmt.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
