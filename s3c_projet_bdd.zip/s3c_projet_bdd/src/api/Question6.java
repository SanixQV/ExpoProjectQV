package api;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Question6 {
	public static void main(String[] args) {
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		Connection conn;
		PreparedStatement pstmt;
		PreparedStatement pstmt2;
		PreparedStatement pstmt3;
		ResultSet res;
		ResultSet res2;
		ResultSet res3;
		Scanner sc = new Scanner(System.in);
		String querySelection = "Select ECRIRE.EMAIL, COUNT(DISTINCT TITRE) from ECRIRE inner join TRAVAILLER on ECRIRE.EMAIL = TRAVAILLER.EMAIL where NOMLABO = ? group by ECRIRE.EMAIL order by COUNT(DISTINCT TITRE) desc";
		String querySelection2 = "Select TITRE from ECRIRE where EMAIL = ?";
		String querySelection3 = "Select COUNT(NOTE), AVG(NOTE) from NOTER where TITRE = ?";
		
		try {
			conn = DriverManager.getConnection(url, args[0], args[1]);
			
			pstmt = conn.prepareStatement(querySelection);
			String nomLabo = sc.nextLine();
			pstmt.setString(1, nomLabo);
			res = pstmt.executeQuery();
			while (res.next()) {
				int nbNotes = 0;
				double moyenne = 0;
				pstmt2 = conn.prepareStatement(querySelection2);
				String email = res.getString(1);
				pstmt2.setString(1, email);
				res2 = pstmt2.executeQuery();
				while(res2.next()) {
					pstmt3 = conn.prepareStatement(querySelection3);
					String titre = res2.getString(1);
					pstmt3.setString(1, titre);
					res3 = pstmt3.executeQuery();
					res3.next();
					nbNotes += res3.getInt(1);
					moyenne += res3.getDouble(2);
				}
				System.out.println("Le labo " + nomLabo + " a engag� l'auteur " + email + "qui a �crit "+ res.getInt(2) + " articles, a re�u " + nbNotes + " notes avec une moyenne " + moyenne);
			}
			sc.close();
			pstmt.close();
			conn.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
