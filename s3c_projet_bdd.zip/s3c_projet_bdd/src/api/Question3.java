package api;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Question3 {
	public static void main(String[] args) {
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		Connection conn;
		PreparedStatement pstmt;
		ResultSet res;
		Scanner sc = new Scanner(System.in);
		String querySelection = "Select NOMCHERCHEUR, PRENOMCHERCHEUR, NOMLABO from CHERCHEUR inner join TRAVAILLER on CHERCHEUR.EMAIL = TRAVAILLER.EMAIL where TRAVAILLER.EMAIL = ?";
		try {
			conn = DriverManager.getConnection(url, args[0], args[1]);
			
			pstmt = conn.prepareStatement(querySelection);
			String s = sc.next();
			pstmt.setString(1, s);
			//pstmt.executeUpdate();
			res = pstmt.executeQuery();
			while (res.next()) {
				System.out.println("NOM : " + res.getString(1) + "\t|\tPRENOM : " + res.getString(2) + "\t|\tLABO : " + res.getString(3));
			}
			sc.close();
			pstmt.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
