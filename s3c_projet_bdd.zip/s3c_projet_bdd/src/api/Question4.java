package api;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Question4 {
	public static void main(String[] args) {
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		Connection conn;
		PreparedStatement pstmt;
		ResultSet res;
		Scanner sc = new Scanner(System.in);
		String querySelection = "Select EMAIL from ANNOTER group by EMAIL having count(TITRE) >= ?";
		try {
			conn = DriverManager.getConnection(url, args[0], args[1]);
			
			pstmt = conn.prepareStatement(querySelection);
			String s = sc.next();
			Integer i = Integer.parseInt(s);
			pstmt.setInt(1, i);
			//pstmt.executeUpdate();
			res = pstmt.executeQuery();
			while (res.next()) {
				System.out.println(res.getString(1) + "a annote plus de "+ i + " fois des articles");
			}
			sc.close();
			pstmt.close();
			conn.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
