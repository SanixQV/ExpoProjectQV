package api;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Question7 {
	public static void main(String[] args) {
		boolean trouve = false;
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		Connection conn;
		PreparedStatement pstmt;
		PreparedStatement pstmt2;
		PreparedStatement pstmt3;
		ResultSet res;
		ResultSet res2;
		ResultSet res3;
		Scanner sc = new Scanner(System.in);
		String querySelection = "Select NOTER.EMAIL, MAX(NOTE), NOMLABO from NOTER inner join ECRIRE on NOTER.TITRE = ECRIRE.TITRE inner join Travailler on NOTER.EMAIL = TRAVAILLER.EMAIL where NOTER.TITRE = ? and NOTE >= ALL(SELECT NOTE from NOTER where TITRE =?) group by NOMLABO, NOTER.EMAIL";
		String querySelection2 = "Select Email from Ecrire where TITRE = ? ";
		String querySelection3 = "Select LABORATOIRE.NOMLABO from LABORATOIRE inner join TRAVAILLER on LABORATOIRE.NOMLABO = TRAVAILLER.NOMLABO where EMAIL = ?";
		try {
			conn = DriverManager.getConnection(url, args[0], args[1]);
			
			pstmt = conn.prepareStatement(querySelection);
			pstmt2 = conn.prepareStatement(querySelection2);
			pstmt3 = conn.prepareStatement(querySelection3);
			String s = sc.nextLine();
			pstmt.setString(1, s);
			pstmt.setString(2, s);
			//pstmt.executeUpdate();
			res = pstmt.executeQuery();
			while (res.next()) {
				int MaxNote = res.getInt(2);
				String EmailNote = res.getString(1);
				String NomLaboNote = res.getString(3);
				pstmt2.setString(1,s);
				res2 = pstmt2.executeQuery();
				while (res2.next()) {
					String email = res2.getString(1);
					pstmt3.setString(1, email);
					res3 = pstmt3.executeQuery();
					while (res3.next()) {
						String NomLabo = res3.getString(1);
						if (NomLabo.equals(NomLaboNote)) {
							trouve = true;
						}
						
					}
				}
				}
			if (trouve) {
				System.out.println("non valid�e");
			}else {
				System.out.println("tout est en regle");
			}
			sc.close();
			pstmt.close();
			conn.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
