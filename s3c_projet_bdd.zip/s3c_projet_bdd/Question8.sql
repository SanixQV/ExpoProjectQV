Question 8 )

Nous avons réalisé les triggers mais nous n'avons pas réussi à les incorporer
Si vous les exécutez dans datagrip, il se peut qu'une erreur survienne : il vous suffit de tout recaler sur une seule ligne.

create or replace trigger verifInsert before insert on NOTER
  for each row
  when (new.EMAIL = old.EMAIL)
  begin
  dbms_output.put_line('Note donnée par un auteur de l article en question'); end;


b)
create table log_chercheurs(
  EMAIL VARCHAR2(500) NOT NULL,
  DATEJ VARCHAR2(500) NOT NULL,
  TYPEA VARCHAR2(500) NOT NULL,
  PRIMARY KEY(EMAIL, DATEJ)
);

create or replace trigger EnregisterLogs before insert or update on ANNOTER
  for each row
  begin
  if inserting then
  insert into log_chercheurs values(:new.EMAIL, TO_CHAR(SYSDATE, 'DD/MM/YYYY HH24:MI:SS'), 'insert');
  elsif updating then
  insert into log_chercheurs values(:new.EMAIL, TO_CHAR(SYSDATE, 'DD/MM/YYYY HH24:MI:SS'), 'update');
  end if;
  end;
