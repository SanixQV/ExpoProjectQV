Bienvenue sur le github de notre projet SOKOBAN & IA.

Equipe : 

- BRIOT ANTHONY
- VRIGNON QUENTIN
- NICOL BENOIT
- SAKER LUCAS

Tuteur: 

VINCENT THOMAS

Info : 

Ceci est un projet tutoré réalisé dans le cadre de notre 2eme année de DUT informatique. 

Le but principal de celui-ci est de développer le jeu Sokoban (lien : https://fr.wikipedia.org/wiki/Sokoban)
avec une IA permettant de résoudre différents niveaux du jeu, et ceci dans le but de vulgariser l'IA.

Pour lancer l'application il suffit d'executer le fichier .jar nommé "Sokoban&IA" présent avec le README.

