package Jeu;
/**
 * @author Anthony Briot
 * @author Lucas Saker
 * @author Quentin Vrignon
 * @author Benoit Nicol
 */

/*
Class qui représente le joueur
un type d'utilisateur spécifique
 */
public class Joueur implements Utilisateur{

}
