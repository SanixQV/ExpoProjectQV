package Jeu;

/**
 * @author Anthony Briot
 * @author Lucas Saker
 * @author Quentin Vrignon
 * @author Benoit Nicol
 */

/*
Interface qui représente un utilisateur (soit Joueur, soit IA)
 */
public interface Utilisateur {
}
